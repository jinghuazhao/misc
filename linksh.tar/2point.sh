#!/usr/local/bin/bash
# shell script to add linkage models
# Jing Hua Zhao 25/11/1999 IoP
#
# Usage: 2point.sh <chromosome#> <# of loci>
# eg. 2point.sh 13 13
#
printf "Chromosome $1, model(s): "
for j in 1 2 3 4 5 6
  do
#   final.out
    if [ -f "finalm$1${j}.out" ]
    then
      mv "final$1m${j}.out" "final$1m${j}.bak"
    fi
    cp /dev/null "final$1m${j}.out"
    if [ $? != '0' ]
    then
      exit 1
    fi
#   stream.out 
    if [ -f "stream$1m${j}.out" ]
    then
      mv "stream$1m${j}.out" "stream$1m${j}.bak"
    fi
    cp /dev/null "stream$1m${j}.out"
    if [ $? != '0' ]
    then
      exit 1
    fi
    rm -f lsp.log
    rm -f lsp.stm
    rm -f lsp.tmp
    rm -f final.dat
    rm -f stream.dat
    rm -f outfile.dat
    rm -f recfile.dat

    printf "${j} "
    k=2
    while [ $[$k <= $2] = "1" ]
    do
      lsp \
	  mlink \
	  "chr$1.ped" "chr$1m${j}.par" \
	  2 \
	   1  $k \
	  0 \
	  0 \
	  1 2 1 6 \
	  0.01 2 1 \
	  0.05 2 1 \
	  0.1 2 1 \
	  0.2 2 1 \
	  0.3 2 1 \
	  0.4 2 1
      if [ $? = '0' -o $? = '1' ]
      then
        cat lsp.log >> "final$1m${j}.out"
        cat lsp.stm >> "stream$1m${j}.out"
        unknown
        if [ $? = '0' ]
        then
          mlink
          if [ $? = '0' ]
          then
            cat outfile.dat >> "final$1m${j}.out"
            cat stream.dat  >> "stream$1m${j}.out"
          fi
        fi
      fi
      k=$[$k+1]
    done
    # table "final$1m${j}.out"
    # linkhet "final$1m${j}.tab" "final$1m${j}.het" "$[$2-1]" 8 137
  done
printf "\n"
