#!/usr/local/bin/bash
2point.sh  1 33
2point.sh  2 31
2point.sh  3 25
2point.sh  4 23
2point.sh  5 21
2point.sh  6 20
2point.sh  7 18
2point.sh  8 23
2point.sh  9 19
2point.sh 10 19
2point.sh 11 18
2point.sh 12 18
2point.sh 13 13
2point.sh 14 14
2point.sh 15 12
2point.sh 16 16
2point.sh 17 12
2point.sh 18 20
2point.sh 19 13
2point.sh 20 12
2point.sh 21 6
2point.sh 22 8
2point.sh  x 16
2point.sh  y 2

