:
# change whatever .pre files to .ped files
# n reflects both loopless and automatic proband selection
makeped d0_chr1.pre chr1.ped n
makeped d0_chr2.pre chr2.ped n
makeped d0_chr3.pre chr3.ped n
makeped d0_chr4.pre chr4.ped n
makeped d0_chr5.pre chr5.ped n
makeped d0_chr6.pre chr6.ped n
makeped d0_chr7.pre chr7.ped n
makeped d0_chr8.pre chr8.ped n
makeped d0_chr9.pre chr9.ped n
makeped d0_chr10.pre chr10.ped n
makeped d0_chr11.pre chr11.ped n
makeped d0_chr12.pre chr12.ped n
makeped d0_chr13.pre chr13.ped n
makeped d0_chr14.pre chr14.ped n
makeped d0_chr15.pre chr15.ped n
makeped d0_chr16.pre chr16.ped n
makeped d0_chr17.pre chr17.ped n
makeped d0_chr18.pre chr18.ped n
makeped d0_chr19.pre chr19.ped n
makeped d0_chr20.pre chr20.ped n
makeped d0_chr21.pre chr21.ped n
makeped d0_chr22.pre chr22.ped n
makeped d0_chrx.pre chrx.ped n
makeped d0_chry.pre chry.ped n


