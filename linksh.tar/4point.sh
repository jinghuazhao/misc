#!/usr/local/bin/bash
# shell script to for 4-point analysis using linkmap
# Jing Hua Zhao 25/02/2000 IoP
#
# Usage: 4point.sh <chromosome#> <loc1> <rec> <loc2> <rec> <loc3>
# eg. 4point.sh 8 11 0.0705 12 0.0696 13
#
printf "Chromosome $1, model(s): "
for j in 1 2 3 4 5 6
  do
#   final.out
    if [ -f "final$1s${j}.out" ]
    then
      mv "final$1s${j}.out" "final$1s${j}.bak"
    fi
    cp /dev/null "final$1s${j}.out"
    if [ $? != '0' ]
    then
      exit 1
    fi
#   stream.out
    if [ -f "stream$1s${j}.out" ]
    then
      mv "stream$1s${j}.out" "stream$1s${j}.bak"
    fi
    cp /dev/null "stream$1s${j}.out"
    if [ $? != '0' ]
    then
      exit 1
    fi
    rm -f lsp.log
    rm -f lsp.stm
    rm -f lsp.tmp
    rm -f final.dat
    rm -f stream.dat
    rm -f outfile.dat
    rm -f recfile.dat

    printf "${j} "
          
    echo
    echo
    echo Run   1 - LINKMAP : p1 p$2 p$4 p$6
    echo
    lsp \
	  linkmap \
	  "chr$1.ped" "chr$1m${j}.par" \
	  4 \
	   1 $2 $4 $6 \
	  1 0 5 0 \
	  0.5 $3 $5
    if [ $? = '0' -o $? = '1' ]
    then
      cat lsp.log >> final$1s${j}.out
      cat lsp.stm >> stream$1s${j}.out
      unknown
      if [ $? = '0' ]
      then
        linkmap
        if [ $? = '0' ]
        then
          cat outfile.dat >> final$1s${j}.out
          cat stream.dat  >> stream$1s${j}.out
        fi
      fi
    fi

    echo
    echo
    echo Run   2 - LINKMAP : p$2 p1 p$4 p$6
    echo
    lsp \
	  linkmap \
	  "chr$1.ped" "chr$1m${j}.par" \
	  4 \
	  $2  1 $4 $6 \
	  1 $3 5 0 \
	  0 $3 $5
    if [ $? = '0' -o $? = '1' ]
    then
      cat lsp.log >> final$1s${j}.out
      cat lsp.stm >> stream$1s${j}.out
      linkmap
      if [ $? = '0' ]
      then
        cat outfile.dat >> final$1s${j}.out
        cat stream.dat  >> stream$1s${j}.out
      fi
    fi

    echo
    echo
    echo Run   3 - LINKMAP : p$2 p$4 p1 p$6
    echo
    lsp \
	  linkmap \
	  "chr$1.ped" "chr$1m${j}.par" \
	  4 \
	  $2 $4  1 $6 \
	  1 $5 5 0 \
	  $3 0 $5
    if [ $? = '0' -o $? = '1' ]
    then
      cat lsp.log >> final$1s${j}.out
      cat lsp.stm >> stream$1s${j}.out
      linkmap
      if [ $? = '0' ]
      then
        cat outfile.dat >> final$1s${j}.out
        cat stream.dat  >> stream$1s${j}.out
      fi
    fi

    echo
    echo
    echo Run   4 - LINKMAP : p$2 p$4 p$6 p1
    echo
    lsp \
	  linkmap \
	  "chr$1.ped" "chr$1m${j}.par" \
	  4 \
	  $2 $4 $6  1 \
	  1 0.5 5 0 \
	  $3 $5 0
    if [ $? = '0' -o $? = '1' ]
    then
      cat lsp.log >> final$1s${j}.out
      cat lsp.stm >> stream$1s${j}.out
      linkmap
      if [ $? = '0' ]
      then
        cat outfile.dat >> final$1s${j}.out
        cat stream.dat  >> stream$1s${j}.out
      fi
    fi
    # table "final$1s${j}.out" 
    # linkhet "final$1s${j}.tab" "final$1s${j}.het" "$[$2-1]" 8 112
  done
printf "\n"

