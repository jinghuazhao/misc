:
# shell script to get heterogeneity analysis
# Jing Hua Zhao 8/3/2000 IoP
# refined from nm.sh
#
# only these chromosomes
for i in 1 2 8 10 13 20 22
  do
    printf "Chromosome ${i}, model(s): "
# only these marker pairs
    case $i in
         1) l=23;m=24;u=25;;
         2) l=19;m=20;u=21;;
         8) l=11;m=12;u=13;;
        10) l=10;m=11;u=12;;
        13) l=2;m=3;u=4;;
        20) l=2;m=3;u=4;;
        22) l=3;m=4;u=5;;
    esac
    for j in 1 2 3 4 5 6
    do
        printf "${j} "
        rt1=final${i}s$j$l-$m
        rt2=final${i}s$j$m-$u
        ./table $rt1.out
        ./table $rt2.out
    # just one block, trick all the recombination rates
    # title
    # points step support intervals
    # option alpha_min ls
    # theta's
    # families
        echo 3-point heterogeneity analysis >homog.tmp
        echo 16 0.05  3.0 >>homog.tmp
        echo 3 0 120 >>homog.tmp
        echo 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.11 0.12 0.13 0.14 0.15 0.16 >>homog.tmp
        echo 112 >>homog.tmp

        cp homog.tmp homog.dat
        awk -f homog.awk $rt1.tab >>homog.dat
        homog
        mv homog.out $rt1.het
        cp homog.tmp homog.dat
        awk -f homog.awk $rt2.tab >>homog.dat
        homog
        mv homog.out $rt2.het

    done
    printf "\n"
  done
grep "H2 vs. H1" *.het >total.het
