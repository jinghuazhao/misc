#!/usr/local/bin/bash
3point.sh  8 11 0.0705 12
3point.sh  8 12 0.0696 13
3point.sh  1 23 0.0688 24
3point.sh  1 24 0.1011 25
3point.sh  2 19 0.0939 20
3point.sh  2 20 0.1198 21
3point.sh 10 10 0.0739 11
3point.sh 10 11 0.0512 12
3point.sh 13  2 0.1355  3
3point.sh 13  3 0.0815  4
3point.sh 20  2 0.0748  3
3point.sh 20  3 0.1129  4
3point.sh 22  3 0.0671  4
3point.sh 22  4 0.0890  5

