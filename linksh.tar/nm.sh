:
# shell script to add linkage models
# Jing Hua Zhao 23/11/1999 IoP
#
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22
  do
    printf "Chromosome ${i}, model(s): "
    awk -f nm.awk chr$i.par >nchr$i.par
    for j in 1 2 3 4 5 6
    do
      printf "${j} "
      sed "3r MODEL${j}.par" nchr$i.par > "chr${i}m${j}.par"
    done
    printf "\n"
  done
for i in x 
  do
    printf "Chromosome ${i}, model(s): "
    awk -f nm.awk chr$i.par >nchr$i.par
    for j in 1 2 3 4 5 6
    do
      printf "${j} "
      sed "3r MODEL${j}x.par" nchr$i.par > "chr${i}m${j}.par"
    done
    printf "\n"
  done
for i in y
  do
    printf "Chromosome ${i}, model(s): "
    awk -f nm.awk chr$i.par >nchr$i.par
    for j in 1 2 3 4 5 6
    do
      printf "${j} "
      sed "3r MODEL${j}.par" nchr$i.par > "chr${i}m${j}.par"
    done
    printf "\n"
  done

