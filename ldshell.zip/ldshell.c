#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_POP 50
#define MAX_IND 1500
#define MAX_LOC 150
#define setlevel 2
#ifndef DEBUG
int check=0;
#else
int check=1;
#endif

/*
  To generate all combination for LD
  JH Zhao 24-10-2001

*/
struct
{
  char popname[50];
  int popn;
} pop[MAX_POP];

typedef struct
{
  char popid[30],id[30];
  short alleles[MAX_LOC][2];
} datatype;
datatype data[MAX_IND],tdata;

int nloci,ipop,iind,npop,nind,ibas;

void as(int);
int getsize(void);
int sort_char(const void *, const void *);

int main(int argc, char **argv)
{
FILE *fi;
int iloc;
char line[1000],rol[1000];

printf("\nLD Shell,JH Zhao 25-10-2001\n");
printf("Max # of populations %d\n",MAX_POP);
printf("Max # of individuals %d\n",MAX_IND);
printf("Max # of markers %d\n",MAX_LOC);
if(argc>2)
{
  fi=fopen(argv[1],"r");
  if(!fi)
  {
    fprintf(stderr,"Sorry, I cannot open %s, exit\n",argv[1]);
    return 0;
  }
  nloci=atoi(argv[2]);
  iind = 0;
  npop = 0;
  while(fgets(line,999,fi)&&sscanf(line,"%s %s %[^\n]",data[iind].id,data[iind].popid,rol)==3)
  {
    if(check) printf("%s %s",data[iind].id,data[iind].popid);
    strcpy(line,rol);
    for(iloc=0;iloc<nloci;++iloc,strcpy(line,rol),*rol='\0')
    {
      sscanf(line,"%d %d %[^\n]",&data[iind].alleles[iloc][0],&data[iind].alleles[iloc][1],rol);
      if(check) printf(" %d %d",data[iind].alleles[iloc][0],data[iind].alleles[iloc][1]);
    }
    if(check) printf("\n");
    iind ++;
  }
  fclose(fi);
  nind=iind;
  printf("\nNumber of individuals=%d\n",nind);
/*sort structure by popid*/
  qsort((void *)data, nind, sizeof(datatype), sort_char);
  if(check)
  {
    printf("\nPopulation and individuals IDs after sorting:\n");
    for(iind=0;iind<nind;iind++)
       printf("%s %s\n",data[iind].popid,data[iind].id);
  }
  npop=getsize();
  printf("Number of populations=%d\n\n",npop);
  ibas=0;
  for(ipop=0;ipop<npop;ipop++)
  {
    as(setlevel);
    ibas += pop[ipop].popn;
    printf("Output to pop%s.out\n",pop[ipop].popname);
  }
}
else
{
  printf("syntax: %s <data file> <#loci>",argv[0]);
}

return 0;
}

void as(int level)
/*to generate all subset in natural order*/
/*  Xiru Chen, Songgui Wang (1987)       */
/*  Modern Regression Analysis           */
/*  Anhui Educational Publishing Co      */
/*  pp203-206                            */
/*  Add level control JH Zhao 24-10-2001 */
{
FILE *fp;
int ind[MAX_LOC],sel[MAX_LOC];
int iz, ib, is, maxint, im, ip;
int irun, nrun;
char fn[50], cmdline[60], popname[50];

strcpy(popname,pop[ipop].popname);
maxint = ip = im = nloci;
nrun = 0;
for (iz = 0; iz < ip; ++iz) ind[iz] = sel[iz] = 0;
ib = 0;
is = 1;
ib = ib % maxint + 1;
do {
   for (iz = im - 1; iz < ip; ++iz) {
       if (ind[iz] < iz + 1) continue;
       ++ind[iz - 1];
       ind[iz] = ind[iz - 1];
   }
   do {
      ++ind[ip - 1];
      is = is % maxint + 1;
      if(ip - im + 1 == level)
      {
        if(nrun == 0)
        {
          sprintf(cmdline,"echo === Population %s ===>pop%s.out",popname,popname);
          system(cmdline);
        }
        sprintf(fn,"pop%stmp.dat",popname);
        fp=fopen(fn,"w");
        if(!fp)
        {
          fprintf(stderr,"Sorry, I cannot open %s, exit\n",fn);
          return;
        }
        for (iz = im - 1; iz < ip; ++iz) sel[ind[iz] - 1] = 1;
        if(check)
        {
          for (iz = 0; iz < ip; ++iz) printf(" %d", ind[iz]);
          printf("\n");
          for (iz = 0; iz < ip; ++iz) printf(" %d", sel[iz]);
          printf("\n");
        }
        for (iind = ibas; iind < ibas + pop[ipop].popn; iind ++)
        {
          tdata=data[iind];
          fprintf(fp,"%s",tdata.id);
          for (iz = 0; iz < ip; ++iz)
          {
             if(sel[iz] == 0) continue;
             fprintf(fp," %2hd %2hd",tdata.alleles[iz][0],tdata.alleles[iz][1]);
             if(iind > ibas) continue;
             sprintf(cmdline,"echo *** marker %d >>pop%s.out",iz+1,popname);
             system(cmdline);
          }
          fprintf(fp,"\n");
        }
        fclose(fp);
        sprintf(cmdline,"2ld pop%stmp.dat >>pop%s.out",popname,popname);
        if(check) printf("%s\n",cmdline);
        irun = system(cmdline);
        nrun ++;
      }
      for (iz = 0; iz < ip; ++iz) sel[iz] = 0;
   }  while (ind[ip - 1] < ip);
   --is;
   if (ind[im - 1] == im) --im;
}  while (im > 0);
}

int getsize()
/*JH Zhao 24/25-10-2001*/
{
int i,j;

for(i=0;i<MAX_POP;i++)
{
  strcpy(pop[i].popname," ");
  pop[i].popn=0;
}
npop=0;
if(nind==1)
{
strcpy(pop[npop].popname,data[0].popid);
pop[npop].popn=1;
npop=1;
}
for(i=0;i<nind-1;i++)
{
  strcpy(pop[npop].popname,data[i].popid);
  for(j=i+1;j<nind;j++)
  {
    if(j==nind-1)
    {
      if(i==0) pop[npop].popn=j-i+1;
      else if(strcmp(data[i].popid,data[j].popid))
      {
        pop[npop].popn=j-i;
        npop++;
        strcpy(pop[npop].popname,data[j].popid);
        pop[npop].popn=1;
      }
      else pop[npop].popn=j-i+1;
      i=j;
    }
    if(strcmp(data[i].popid,data[j].popid))
    {
      pop[npop].popn=j-i;
      i=j-1;
      goto next;
    }
  }
next:
npop++;
}
for(j=0;j<npop;j++) printf("%5d of population %s\n",pop[j].popn,pop[j].popname);

return npop;
}

int sort_char( const void *a, const void *b)
/*JH Zhao 18-11-1999*/
{
  return( strcmp((char *)a,(char *)b) );
}
