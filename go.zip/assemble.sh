#!/bin/bash

export ROOT=/data/genetics/GWA/snptest
export IN=/home/jhz22/mrc/projects/epic5k/assemble.sas
export OUT=assemble2.sas
export CMD="sas -noterminal -work /data/genetics/scratch $OUT "

cd $ROOT/zbmi
sed 's/diastol2/zbmi/g' $IN > $OUT
$CMD

cd $ROOT/zheight
sed 's/diastol2/zheight/g' $IN > $OUT
$CMD

cd $ROOT/best/zL10waist
sed 's/diastol2/zL10waist/g' $IN > $OUT
$CMD
cd $ROOT/best/zL10WHT2
sed 's/diastol2/zL10WHT2/g' $IN > $OUT
$CMD
cd $ROOT/best/zL10WHR
sed 's/diastol2/zL10WHR/g' $IN > $OUT
$CMD
cd $ROOT/best/zL10WHT
sed 's/diastol2/zL10WHT/g' $IN > $OUT
$CMD

cd $ROOT/cecilia/zL10WHT2
sed 's/diastol2/zL10WHT2/g' $IN > $OUT
$CMD
cd $ROOT/cecilia/zL10WHRHT2
sed 's/diastol2/zL10WHRHT2/g' $IN > $OUT
$CMD

cd $ROOT/uniform1/bmi/male
sed 's/diastol2/bmi/g' $IN > $OUT
$CMD
cd $ROOT/uniform1/bmi/female
sed 's/diastol2/bmi/g' $IN > $OUT
$CMD
cd $ROOT/uniform1/rbmi/male
sed 's/diastol2/rbmi/g' $IN > $OUT
$CMD
cd $ROOT/uniform1/rbmi/female
sed 's/diastol2/rbmi/g' $IN > $OUT
$CMD

cd $ROOT/uniform2/rwht2/male
sed 's/diastol2/rwht2/g' $IN > $OUT
$CMD
cd $ROOT/uniform2/rwht2/female
sed 's/diastol2/rwht2/g' $IN > $OUT
$CMD
cd $ROOT/uniform2/rwh/male
sed 's/diastol2/rwh/g' $IN > $OUT
$CMD
cd $ROOT/uniform2/rwh/female
sed 's/diastol2/rwh/g' $IN > $OUT
$CMD
cd $ROOT/uniform2/rwaist/male
sed 's/diastol2/rwaist/g' $IN > $OUT
$CMD
cd $ROOT/uniform2/rwaist/female
sed 's/diastol2/rwaist/g' $IN > $OUT
$CMD
