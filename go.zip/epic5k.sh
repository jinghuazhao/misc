# 2/10/2007 MRC-Epid JHZ

NO = 1
MINOR = 1
HAPLO = v1/genotypes_chr$(NO)_CEU_r21_nr_fwd_phased_all_by_snp_no_mono
LEGEND = v1/genotypes_chr$(NO)_CEU_r21_nr_fwd_legend_all_no_mono
GENOTYPE = geno$(NO)-$(MINOR).txt 
MAP = v1/CEU_files/genetic_map_chr$(NO).txt 
STRAND = v1/CEU_files/chr$(NO).strand
NE = 11418
OUT = chr$(NO)-$(MINOR).out
INFO = chr$(NO)-$(MINOR).info
REGION = 45413 245428743
N = 3552

ok:
	./$(arch)/impute -h $(HAPLO) -l $(LEGEND) -g $(GENOTYPE) -m $(MAP) -s $(STRAND) -Ne $(NE) -o $(OUT) -i $(INFO) -int $(REGION) -nind $(N) > /dev/null
# All other options

#-exclude_snps <file>
#-int <lower> <upper>
#-buffer <250>
#-call_thresh <0.9>
#-nind <# individuals>
#-os 1-3

# NB
# make -f epick.sh NO=<chr_no>
