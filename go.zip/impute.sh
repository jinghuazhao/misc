#!/bin/bash
#27-1-2008 MRC-Epid JHZ
#To be executed either in full or in part (cut/paste)

awk '{gsub(/epic5k.sh/,"impute.subs");gsub(/REGION/,"R");print}' log1 log2 log3 > logs

grep "NO=1 " logs > 1.sh
grep "NO=2 " logs > 2.sh
grep "NO=3 " logs > 3.sh
grep "NO=4 " logs > 4.sh
grep "NO=5 " logs > 5.sh
grep "NO=6 " logs > 6.sh
grep "NO=7 " logs > 7.sh
grep "NO=8 " logs > 8.sh
grep "NO=9 " logs > 9.sh
grep "NO=10" logs > 10.sh
grep "NO=11" logs > 11.sh
grep "NO=12" logs > 12.sh
grep "NO=13" logs > 13.sh
grep "NO=14" logs > 14.sh
grep "NO=15" logs > 15.sh
grep "NO=16" logs > 16.sh
grep "NO=17" logs > 17.sh
grep "NO=18" logs > 18.sh
grep "NO=19" logs > 19.sh
grep "NO=20" logs > 20.sh
grep "NO=21" logs > 21.sh
grep "NO=22" logs > 22.sh

ssh -f $node08 "cd /data/genetics/gwas;pwd;./1.sh"  ## 1st batch
ssh -f $node09 "cd /data/genetics/gwas;pwd;./2.sh"
ssh -f $node10 "cd /data/genetics/gwas;pwd;./3.sh"
ssh -f $node11 "cd /data/genetics/gwas;pwd;./4.sh"
ssh -f $node12 "cd /data/genetics/gwas;pwd;./5.sh"
ssh -f $node13 "cd /data/genetics/gwas;pwd;./6.sh"
ssh -f $node14 "cd /data/genetics/gwas;pwd;./7.sh"
ssh -f $node15 "cd /data/genetics/gwas;pwd;./8.sh"
ssh -f $node08 "cd /data/genetics/gwas;pwd;./9.sh"  ## 2nd batch
ssh -f $node09 "cd /data/genetics/gwas;pwd;./10.sh"
ssh -f $node10 "cd /data/genetics/gwas;pwd;./11.sh"
ssh -f $node11 "cd /data/genetics/gwas;pwd;./12.sh"
ssh -f $node12 "cd /data/genetics/gwas;pwd;./13.sh"
ssh -f $node13 "cd /data/genetics/gwas;pwd;./14.sh"
ssh -f $node14 "cd /data/genetics/gwas;pwd;./15.sh"
ssh -f $node15 "cd /data/genetics/gwas;pwd;./16.sh"
ssh -f $node08 "cd /data/genetics/gwas;pwd;./17.sh" ## 3rd batch
ssh -f $node09 "cd /data/genetics/gwas;pwd;./18.sh"
ssh -f $node10 "cd /data/genetics/gwas;pwd;./19.sh"
ssh -f $node11 "cd /data/genetics/gwas;pwd;./20.sh"
ssh -f $node12 "cd /data/genetics/gwas;pwd;./21.sh"
ssh -f $node13 "cd /data/genetics/gwas;pwd;./22.sh"

ssh $c02 "who;ps x"
ssh $c03 "who;ps x"
ssh $c04 "who;ps x"
ssh $c05 "who;ps x"
ssh $c06 "who;ps x"
ssh $c07 "who;ps x"
ssh $c08 "who;ps x"
ssh $c09 "who;ps x"
ssh $c10 "who;ps x"
ssh $c11 "who;ps x"
ssh $c12 "who;ps x"
ssh $c13 "who;ps x"
ssh $c14 "who;ps x"
ssh $c15 "who;ps x"
