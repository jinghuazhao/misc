# 16-10-2007 MRC-Epid JHZ

export TRAIT=trait.raw
echo -e "id idn missing age zbmi zL10waist zL10WHT2 zL10WHR\n0 0 0 3 P P P P" > header

for i in `seq $1 $2`;
do
    for j in `seq 1 30`
    do
       echo "Chromosome-Partition:" $i-$j
       export NO=$i
       export MINOR=$j
       sh gtool.subs
    done
done

# command format:
# sh snptest.sh <start> <end>
# <start> <end> are the closed intervals representing chromosomes

