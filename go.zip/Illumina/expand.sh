#!/bin/bash
#2-2-2008 MRC-Epid JHZ

for j in `seq 1 22`
do
    if [ $j -le 9 ]; then
         i=0$j
    else 
         i=$j
    fi
    echo -e "Transforming chromosome $i ...\n"
    export DATA=Obesity_Illuminus_dbSNP_gt_$i
    awk -f expand.awk $DATA.tab > $DATA.ok
done
for i in X XY;
do
    echo -e "Transforming chromosome $i ...\n"
    export DATA=Obesity_Illuminus_dbSNP_gt_$i
    awk -f expand.awk $DATA.tab > $DATA.ok
done
