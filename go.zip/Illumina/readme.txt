Programs to deal with Illumina 317K data

14-2-2008 MRC-Epid JHZ

The wide format

xpose.sh	driver in bash
xpose.awk	awk program
w2l.sas		SAS program
Illumina.awk	awk program add IDs to the first column

The flipped format

expand.sh	bash script to call expand.awk
expand.awk	awk program to exclude individuals and separate alleles
illumina.sas	SAS program to prepare for data in SNPTEST format

The genotype files to be processed are self-evident from the programs. There is also a file 
containing the IDs of individuals to be excluded from the analysis and used by expand.awk.
The duplicates were checked with dup.sh and dup.awk but eventually this is unnecessary.

The Build 35 annotation file ILMN_HumanHap300_SNPlist.txt is used along with illumbina.sas.
The Build 36 equivalent is HumanHap300v2_318237_SNPs.txt but the legend and haplotype files
from HAPMAP for the same build are required if it is to be used, and possibly in conjunction
with the Affymetrix 500K GeneChips data.
