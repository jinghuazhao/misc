#!/bin/bash
#5-2-2008 MRC-Epid JHZ

awk '{if(NR>1) print$1}' ../Duplicates_gt_01.raw > dup.id
for j in `seq 1 22`
do
    if [ $j -le 9 ]; then
         i=0$j
    else 
         i=$j
    fi
    echo -e "Extracting chromosome $i ...\n"
    export DATA=Obesity_Illuminus_dbSNP_gt_$i
    awk -f dup.awk $DATA.ok > $DATA.dup
done
for i in X XY;
do
    echo -e "Extracting chromosome $i ...\n"
    export DATA=Obesity_Illuminus_dbSNP_gt_$i
    awk -f dup.awk $DATA.ok > $DATA.dup
done
