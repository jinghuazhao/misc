#!/bin/bash
# 8-11-2007 MRC-Epid JHZ

export home=/data/genetics/GWA/Obesity/sep-2007/Illuminus
export scratch=/data/genetics/scratch/

for j in `seq 1 22` X XY;
do
    if [ $j -le 9 ]
    then
         i=0$j
    else 
         i=$j
    fi
    echo -e "Transforming chromosome(s) $i ...\n"
    export CASE=$scratch/Obesity_Illuminus_gt_CASES_$i
    export CONTROL=$scratch/Obesity_Illuminus_gt_CONTROLS_$i
    awk -f xpose.awk $CASE.txt > $CASE.ok
    awk -f xpose.awk $CONTROL.txt > $CONTROL.ok
done
