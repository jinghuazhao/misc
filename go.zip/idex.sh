# 11-12-2007 MRC-Epid JHZ

export ROOT=/data/genetics/GWA
export AWK=$ROOT/snptest/work/idex.awk
export IN=$ROOT/impute
export OUT=$ROOT/impute/cohort

for i in `seq $1 $2`;
do
    for j in `seq 1 30`
    do
       echo "Chromosome-Partition:" $i-$j
       export NO=$i
       export MINOR=$j
       awk -f $AWK $IN/geno$i-$j.txt > $OUT/out$i-$j.txt
    done
done
