#26-1-2008 MRC-Epid JHZ
#!/bin/bash

export ROOT=/data/genetics/GWA/snptest/Affy500k
export IN=/home/jhz22/mrc/projects/epic5k/assemble.sas
export CMD="sas -noterminal -work /data/genetics/scratch $IN "

function run {
pwd
for i in `seq 1 22`;
do
    for j in `seq 1 30`
    do
        awk '{tt=ENVIRON["batch"];gsub(/_age|_frequentist|_cov_all|[ ]+$/,"");gsub(tt,"y");print}' chr$i-$j.lst>chr$i-$j.out
    done
done
}

for BEST in zBMI zL10Waist zL10WHT2 zL10WHR zL10Weight zL10WaistAdjHT zL10WeightAdjHT
do 
    export batch=$BEST
    if [ "$BEST" = "zL10WaistAdjHT" ]; then
       export batch=zL10Waist
    fi
    if [ "$BEST" = "zL10WeightAdjHT" ]; then
       export batch=zL10Weight
    fi
    cd $ROOT/BEST/$BEST
    run
    $CMD
done

for UNIFORM1 in BMI rBMI
do
    export batch=$UNIFORM1
    cd $ROOT/UNIFORM1/$UNIFORM1/male
    run
    $CMD
    cd $ROOT/UNIFORM1/$UNIFORM1/female
    run
    $CMD
done

for UNIFORM2 in rWaist rWaistadjHT rWHT2 rWHR rWeight rWeightadjHT
do
    export batch=$UNIFORM2
    if [ "$UNIFORM2" = "rWeightedadjHT" ]; then
       export batch=rWeight
    fi
    cd $ROOT/UNIFORM2/$UNIFORM2/male
    run
    $CMD
    cd $ROOT/UNIFORM2/$UNIFORM2/female
    run
    $CMD
done

for CECILIA in zL10WHT zL10WHT2adjBMI zL10WHRHT2adjBMI
do 
    export batch=$CECILIA
    if [ "$CECILIA" = "zL10WHT2adjBMI" ]; then
       export batch=zL10WHT2
    fi
    if [ "$CECILIA" = "zL10WHRHT2adjBMI" ]; then
       export batch=zL10WHRHT2
    fi
    cd $ROOT/CECILIA/$CECILIA
    run
    $CMD
done

for BP in systol2 diastol2
do
    export batch=$BP
    cd $ROOT/BP/$BP/all
    run
    $CMD
    cd $ROOT/BP/$BP/male
    run
    $CMD
    cd $ROOT/BP/$BP/female
    run
    $CMD
done
