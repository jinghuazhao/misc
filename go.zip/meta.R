# 29-5-2007 MRC-Epid JHZ

library(foreign)
setwd(".")
meta5 <- read.dta("meta5.dta")
attach(meta5)

library(meta)
by(meta5,locus,function(x) metagen(b,se,data=x))

