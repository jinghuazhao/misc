#!/bin/bash
# 11-12-2007 MRC-Epid JHZ

function run {
case $3 in
BEST)
echo -e "id idn missing age height zBMI zL10waist zL10WHT2 zL10WHR zL10Weight\n0 0 0 3 3 P P P P P" > header
    ;;
UNIFORM1)
echo -e "id idn missing age age2 BMI rBMI\n0 0 0 3 3 P P" > header
    ;;
UNIFORM2)
echo -e "id idn missing age age2 height rWaist rWHT2 rWHR rWeight\n0 0 0 3 3 3 P P P P" > header
    ;;
UNIFORM2_12)
echo -e "id idn missing age age2 rWaist rWHT2 rWHR rWeight\n0 0 0 3 3 P P P P" > header
    ;;
CECILIA)
echo -e "id idn missing age bmi zL10WHT zL10WHT2 zL10WHRHT2\n0 0 0 3 3 P P P" > header
    ;;
esac
for i in `seq $1 $2`;
do
    for j in `seq 1 30`
    do
       echo "Chromosome-Partition:" $i-$j
       export NO=$i
       export MINOR=$j
       sh /data/genetics/GWA/snptest/Affy500k.subs
    done
done
}
if [ $# -ne 4 ]; then
   echo "Syntax:"
   echo "sh snptest2.sh <phenotype #> <start chromosome> <end chromosome> <dataset name>"
   echo "where # is the phenotype number in the header (or .gen) file"
   echo "<start> <end> are the closed intervals representing chromosomes"
   echo "<dataset> is one of BEST,UNIFORM1,UNIFORM2,UNIFORM2_12,CECILIA"
   exit
fi
echo -e "Analysing phenotype number $1 in chromosome(s) $2-$3 of data $4.raw ...\n"
export PHENO=$1
export RAW=$4
export COV=
export OPTS=
cd Affy500k
case $4 in
    BEST)
      cd $4
      export RAW=BEST
      case $1 in
      1)
         cd zBMI
         ;;
      2)
         export COV="-cov 1"
         cd zL10Waist
         ;;
      3)
         export COV="-cov 1"
         cd zL10WHT2
         ;;
      4)
         export COV="-cov 1"
         cd zL10WHR
         ;;
      5)
         export COV="-cov 1"
         cd zL10Weight
         ;;
      6)
         export PHENO="2"
         export COV="-cov_all"
         cd zL10WaistAdjHT
         ;;
      7)
         export PHENO="5"
         export COV="-cov_all"
         cd zL10WeightAdjHT
         ;;
      esac 
      run $2 $3 $4
      ;;
    UNIFORM1)
      cd $4
      export COV="-cov_all"
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/FEMALE.DAT"
      case $1 in
      1)
         cd BMI/male
         ;;
      2)
         cd rBMI/male
         ;;
      esac
      run $2 $3 $4
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/MALE.DAT"
      cd ../female
      run $2 $3 $4
      ;;
    UNIFORM2)
      cd $4
      export COV="-cov_all"
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/FEMALE.DAT"
      case $1 in
      1)
         cd rWaistadjHT/male
         ;;
      2)
         export PHENO="4"
         cd rWeightadjHT/male
         ;;
      esac
      run $2 $3 $4
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/MALE.DAT"
      cd ../female
      run $2 $3 $4
      ;;
    UNIFORM2_12)
      cd UNIFORM2
      export COV="-cov_all"
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/FEMALE.DAT"
      case $1 in
      1)
         cd rWaist/male
         ;;
      2)
         cd rWHT2/male
         ;;
      3)
         cd rWHR/male
         ;;
      4)
         cd rWeight/male
         ;;
      esac
      run $2 $3 $4
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/MALE.DAT"
      cd ../female
      run $2 $3 $4
      ;;
    CECILIA)
      cd $4
      case $1 in
      1)
         export COV="-cov 1"
         cd zL10WHT
         ;;
      2)
         export COV="-cov_all"
         cd zL10WHT2adjBMI
         ;;
      3)
         export COV="-cov_all"
         cd zL10WHRHT2adjBMI
         ;;
      esac
      run $2 $3 $4
      ;;
    *)
      echo an invalid choice!
      exit
esac
