#!/bin/bash
# 30-10-2007 MRC-Epid JHZ

if [ $# -ne 4 ]; then 
   echo "Syntax:"
   echo "sh snptest.sh <phenotype #> <start chromosome> <end chromosome> <dataset name>"
   echo "where # is the phenotype number in the header (or .gen) file"
   echo "<start> <end> are the closed intervals representing chromosomes"
   echo "<dataset> is test,zbmi,zheight,best,cecilia,uniform1,uniform2"
   exit
fi
echo -e "Analysing phenotype number $1 in chromosome(s) $2-$3 of data $4(1/2).raw ...\n"
export PHENO=$1
export RAW=$4
function run {
for i in `seq $1 $2`;
do
    for j in `seq 1 30`
    do
       echo "Chromosome-Partition:" $i-$j
       export NO=$i
       export MINOR=$j
       sh /data/genetics/GWA/snptest/snptest.subs
    done
done
}
function title {
case $1 in
zbmi|zheight)
    echo -e "id idn missing $1\n0 0 0 P" > header
    ;;
test|best)
    echo -e "id idn missing age zL10waist zL10WHT2 zL10WHR zL10WHT\n0 0 0 3 P P P P" > header
    ;;
cecilia)
    echo -e "id idn missing age bmi zL10WHT2 zL10WHRHT2\n0 0 0 3 3 P P" > header
    ;;
uniform1)
    echo -e "id idn missing age age2 bmi rbmi rwht2 rwh\n0 0 0 3 3 P P P P" > header
    ;;
uniform2)
    echo -e "id idn missing age age2 height rwaist\n0 0 0 3 3 3 P" > header
    ;;
esac
}
cd $4
export COV="-cov_all"
export OPTS=
case $4 in
    test|zbmi|zheight)
      export COV=
      title $4
      run $2 $3
      ;;
    best)
      case $1 in
      1)
         cd zL10waist
         title $4
         ;;
      2)
         cd zL10WHT2
         title $4
         ;;
      3)
         cd zL10WHR
         title $4
         ;;
      4)
         cd zL10WHT
         title $4
         ;;
      esac 
      run $2 $3
      ;;
    cecilia)
      case $1 in
      1)
         cd zL10WHT2
         title $4
         ;;
      2)
         cd zL10WHRHT2
         title $4
         ;;
      esac
      run $2 $3
      ;;
    uniform1)
      export RAW=uniform1
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/female.dat"
      case $1 in
      1)
         cd bmi/male
         title $4
         ;;
      2)
         cd rbmi/male
         title $4
         ;;
      3)
         cd ../uniform2/rwht2/male
         title $4
         ;;
      4)
         cd ../uniform2/rwh/male
         title $4
         ;;
      esac
      run $2 $3
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/male.dat"
      cd ../female
      title $4
      run $2 $3
      ;;
    uniform2)
      export RAW=uniform2
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/female.dat"
      cd rwaist/male
      title $4
      run $2 $3
      export OPTS="-exclude_samples /data/genetics/GWA/snptest/work/male.dat"
      cd ../female
      title $4
      run $2 $3
      ;;
    *)
      echo an invalid choice!
      exit
esac
